#include "cachelab.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

struct Cache {
	struct Set* sets;
};

struct Set {
	struct Line* lines;
};

struct Line {
	int valid;
	unsigned long tag;
	unsigned long LRU_Index;
	char *data;
};


// in: line from input, out: address as a unsigned long
unsigned long getAddress(char *singleLine){
	unsigned int address;
	sscanf(singleLine, "%x", &address);
	unsigned long laddr = address;
	return laddr;
}

// call to cache 
// in: address
// action: searches by tag
int sortCache(struct Cache cache, unsigned long address, char opertat){
	return 0;
}

int main(int argc, char *argv[]) {
	int set_lim=-1, line_lim=-1, block_bits=-1, help=0, verbose=0;
	char filename[32] = {0};
	printf("%s\n", argv[1]);
	for (int i=1;i<argc;i++) {
		char argbuf[4];
		char arg[4];
		strncpy(argbuf,argv[i],4);
		int n = sscanf(argbuf,"-%s",arg);
		printf("X%s X%s X%d X%s X%d X%c\n",argv[i],argbuf,n,arg,i,*arg);
		if (*arg=='h' || (sizeof(arg)>1 && *(arg+1)=='h')) help=1;
		else if (*arg=='v') verbose=1;
		else if (*arg=='t') strncpy(filename,argv[++i],32);			
		else if (*arg=='s') set_lim = atoi(argv[++i]);
		else if (*arg=='E') line_lim = atoi(argv[++i]);
		else if (*arg=='b') block_bits = atoi(argv[++i]);
		else {
			printf("unknown argument\n");
			return -1;
		}
	}
	
	if (set_lim<0) {
		printf("Need set bits\n");
		return -1;
	} else if (line_lim<0) {
		printf("Need associativity\n");
		return -1;
	} else if (block_bits<0) {
  		printf("Need block bits\n");
		return -1;
	} else if (strlen(filename)==0) {
		printf("Need filename\n");
		return -1;
	}
	
	printf("%d %d %d %d %d %s\n",set_lim,line_lim,block_bits,help,verbose,filename);
		
	struct Cache *cache = malloc(sizeof(struct Cache *));
	cache->sets = (struct Set *)malloc((1 << set_lim) * sizeof(struct Set *));
	for (int i=0;i<set_lim;i++) {
  		cache->sets[i].lines = (struct Line *)malloc(line_lim * sizeof(struct Line *));
		for (int j=0;j<line_lim;j++) {
			cache->sets[i].lines[j].data = (char *)malloc((1 < block_bits) * sizeof(char *));
		}
	}

	FILE *fPointer;
	fPointer = fopen(filename, "r");
	char singleLine[20];

	while(!feof(fPointer)) {
		fgets(singleLine, 20, fPointer);
		// run function that reads line and puts into cache or whatever
		// needs to separate address from line
	}
	fclose(fPointer);

	printSummary(0,0,0);
	return 0;
}

